$("#rotate-tada").Morphext({
    animation: "fadeIn",
    separator: ",",
    speed: 8000,
});
$("#rotate-tada-1").Morphext({
    animation: "fadeIn",
    separator: ",",
    speed: 8000,
});
$("#rotate-tada-2").Morphext({
    animation: "fadeIn",
    separator: ",",
    speed: 8000,
});
$("#rotate-tada-3").Morphext({
    animation: "fadeIn",
    separator: ",",
    speed: 8000,
});
$("#rotate-tada-4").Morphext({
    animation: "fadeIn",
    separator: ",",
    speed: 8000,
});
$("#rotate-tada-5").Morphext({
    animation: "fadeIn",
    separator: ",",
    speed: 8000,
});
$("#rotate-tada-6").Morphext({
    animation: "fadeIn",
    separator: ",",
    speed: 8000,
});
